package com.coderforfun.forohub.domain.usuario;

public record DatosAutenticacionUsuario() {
}
