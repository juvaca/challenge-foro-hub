package com.coderforfun.forohub.domain.topico.validaciones;

public interface ValidadorDeTopicos {

    public void validarTopico(String titulo, String mensaje);
}
