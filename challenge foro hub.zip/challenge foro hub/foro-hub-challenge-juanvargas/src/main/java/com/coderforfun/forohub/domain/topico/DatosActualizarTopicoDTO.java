package com.coderforfun.forohub.domain.topico;

public record DatosActualizarTopicoDTO(String titulo,

                                       String mensaje,

                                       String status,

                                       String curso) {
}
