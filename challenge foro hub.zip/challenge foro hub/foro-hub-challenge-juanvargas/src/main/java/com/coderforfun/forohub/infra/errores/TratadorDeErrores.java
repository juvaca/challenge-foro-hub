package com.coderforfun.forohub.infra.errores;public class TratadorDeErrores {
}
