package com.coderforfun.forohub.infra.security;public class SecurityConfigurations {
}
